Responsive Mobile
=============

Responsive II (codename Responsive Mobile) is a flexible foundation with fluid grid system that adapts your website to mobile devices and the desktop or any other viewing environment. Theme features 9 Page Templates, 11 Widget Areas, 6 Template Layouts, 4 Menu Positions and more. Powerful but simple Theme Options for full CMS control with easy Logo Upload and Social Networking etc. Responsive II is WooCommerce Compatible, Multilingual Ready (WPML), RTL-Language Support, Retina-Ready, Search Engine Friendly and W3C Markup Validated. Cross-Browser compatible. <a href="http://cyberchimps.com/forum/free/responsive/">Official support forum</a> (http://cyberchimps.com/forum/free/responsive/)


Responsive Mobile WordPress Theme, Copyright 2014 CyberChimps
Responsive Mobile is distributed under the terms of the GNU GPL

Responsive Mobile WordPress Theme is derived from Underscores WordPress Theme, Copyright 2013 Automattic, Inc.
Underscores WordPress Theme is distributed under the terms of the GNU GPL

Responsive Mobile WordPress Theme incorporates code from Responsive WordPress Theme, Copyright (C) 2003-2014 Emil Uzelac, CyberChimps Inc
Responsive WordPress Theme is distributed under the terms of the GNU GPL

All Images are created by CyberChimps Inc are GPL

Responsive Mobile WordPress Theme bundles the following third-party resources:

Bootstrap, Copyright (c) 2011-2014 Twitter, Inc
Bootstrap is licensed under MIT
Source: http://getbootstrap.com/

FitVids.js, Copyright 2013, Chris Coyier + Dave Rupert
FitVids.js is released under the WTFPL license - http://sam.zoy.org/wtfpl/
Source: http://fitvidsjs.com/

HTML5 Placeholder jQuery Plugin, Copyright Mathias Bynens
HTML5 Placeholder jQuery Plugin is licensed under MIT
Source: http://mths.be/placeholder

response.js, Copyright 2014 Ryan Van Etten
response.js is licensed under MIT
Source: https://github.com/ryanve/response.js

Retina.js, Copyright 2014 Imulus, LLC
Retina.js is licensed under MIT
Source: http://retinajs.com/

Modernizr
Modernizr is licensed under MIT & BSD
Source: http://modernizr.com/
